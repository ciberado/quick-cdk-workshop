#!/bin/sh

rm /var/www/html/index.nginx-debian.html